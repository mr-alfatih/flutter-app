package com.example.mcdonalds

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
