# McDonald's Touch Interface Concept App
Source Code - Enjoy !

Nice, clean and modern McDonald's Touch Interface Concept App in Flutter

# Most Important Social Media
YouTube: https://www.youtube.com/channel/UCQheyq1vvmd0RaKv1EDyGfA

I hope you liked it, and dont forget to like, subscribe, share this video with your friends, and star the repository on GitHub!

# Social Media
GitHub: https://github.com/gerfagerfa
Instagram: https://instagram.com/gerfagerfa
LinkedIn: https://www.linkedin.com/in/gerfagerfa

# Inspiration
https://dribbble.com/shots/7049291-McDonald-s-Touch-Interface-Concept
